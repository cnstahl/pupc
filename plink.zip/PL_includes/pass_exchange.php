<center>
<?php
	//Set pass exchange variables
	$pass_submit = $_POST["pass_submit"];

	//Verify that the question was submitted
	if ($pass_submit == "submit")
	{
		$club = $_POST["club"];
		$date = $_POST["date"];
		$quantity = $_POST["quantity"];
		$type = $_POST["type"];

		add_pass($club, $date, $quantity, $type);
		$pass_result = "Pass posted successfully!";
	}
?>
<form method="post" id="greeting_block">  
	<h3 class="greeting_step"></h1><input type="text" name="club" placeholder="Which club?" class="greeting_desc"></input>
	<h3 class="greeting_step"></h1><input type="text" name="date" placeholder="When? (MM/DD/YY)" class="greeting_desc"></input>
	<h3 class="greeting_step"></h1><input type="text" name="quantity" placeholder="How many?" class="greeting_desc"></input>
	<h3 class="greeting_step"></h1><select name="type" class="greeting_desc"><option>Offer or Request?</option><option value="1">Request</option><option value="2">Offer</option></select>
	<h3 class="greeting_step"></h1><input type="submit" name="pass_submit" value="submit" class="home_buttons"></input>
</form>
</center>
<h3>Offers</h3>
<ul class="unstyled">
<?php display_offers(); ?>
</ul>
<hr />
<h3>Requests</h3>
<ul class="unstyled">
<?php display_requests(); ?>
</ul>